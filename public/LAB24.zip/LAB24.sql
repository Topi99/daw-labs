﻿CREATE TABLE ClientesBanca(
  NoCuenta     VARCHAR(5) PRIMARY KEY,
  Nombre       VARCHAR(30),
  Saldo        NUMERIC(10, 2),
  
);

CREATE TABLE TiposMovimiento(
  ClaveM       VARCHAR(2) PRIMARY KEY, 
  Descripcion  varchar(30)
);

CREATE TABLE Movimientos(
  Fecha        DATETIME,
  Monto        numeric(10, 2),
  NoCuenta     VARCHAR(5)
    FOREIGN KEY 
    REFERENCES ClientesBanca(NoCuenta),
  ClaveM       VARCHAR(2)
    FOREIGN KEY
    REFERENCES TiposMovimiento(ClaveM)
); 

BEGIN TRANSACTION PRUEBA1 
INSERT INTO ClientesBanca VALUES('001', 'Manuel Rios Maldonado', 9000); 
INSERT INTO ClientesBanca VALUES('002', 'Pablo Perez Ortiz', 5000); 
INSERT INTO ClientesBanca VALUES('003', 'Luis Flores Alvarado', 8000); 
COMMIT TRANSACTION PRUEBA1; 

SELECT * FROM ClientesBanca;

BEGIN TRANSACTION PRUEBA2 
INSERT INTO ClientesBanca VALUES('004','Ricardo Rios Maldonado',19000); 
INSERT INTO ClientesBanca VALUES('005','Pablo Ortiz Arana',15000); 
INSERT INTO ClientesBanca VALUES('006','Luis Manuel Alvarado',18000); 

SELECT * FROM ClientesBanca;

ROLLBACK TRANSACTION PRUEBA2;

BEGIN TRANSACTION PRUEBA3 
INSERT INTO TiposMovimiento VALUES('A','Retiro Cajero Automatico'); 
INSERT INTO TiposMovimiento VALUES('B','Deposito Ventanilla'); 
COMMIT TRANSACTION PRUEBA3 

BEGIN TRANSACTION PRUEBA4 
INSERT INTO Movimientos VALUES(GETDATE(),500,'001','A'); 
UPDATE ClientesBanca SET Saldo = Saldo-500 
WHERE NoCuenta='001' 
COMMIT TRANSACTION PRUEBA4 

SELECT * from Movimientos

BEGIN TRANSACTION PRUEBA5 
INSERT INTO ClientesBanca VALUES('005','Rosa Ruiz Maldonado',9000);
INSERT INTO ClientesBanca VALUES('006','Luis Camino Ortiz',5000); 
INSERT INTO ClientesBanca VALUES('001','Oscar Perez Alvarado',8000); 


IF @@ERROR = 0 
COMMIT TRANSACTION PRUEBA5 
ELSE 
BEGIN 
PRINT 'A transaction needs to be rolled back' 
ROLLBACK TRANSACTION PRUEBA5 
END 

CREATE PROCEDURE REGISTRAR_RETIRO_CAJERO
  @uNoCuenta VARCHAR(5),
  @uMonto    NUMERIC(10,2) 
AS
  BEGIN TRANSACTION PRUEBA5 
    INSERT INTO Movimientos VALUES(GETDATE(),500,@uNoCuenta,@uMonto); 
    UPDATE ClientesBanca 
      SET Saldo = Saldo - @uMonto
      WHERE NoCuenta=@uNoCuenta
  
  IF @@ERROR = 0 
    COMMIT TRANSACTION PRUEBA5 
  ELSE 
    BEGIN 
    PRINT 'A transaction needs to be rolled back' 
    ROLLBACK TRANSACTION PRUEBA5 
  END 
GO

DROP PROCEDURE REGISTRAR_RETIRO_CAJERO

EXECUTE REGISTRAR_RETIRO_CAJERO '001', 500;

SELECT * FROM ClientesBanca WHERE NoCuenta = '001'

CREATE PROCEDURE REGISTRAR_DEPOSITO_VENTANILLA
  @uNoCuenta VARCHAR(5),
  @uMonto    NUMERIC(10,2) 
AS
  BEGIN TRANSACTION PRUEBA5 
    INSERT INTO Movimientos VALUES(GETDATE(),500,@uNoCuenta,@uMonto); 
    UPDATE ClientesBanca 
      SET Saldo = Saldo + @uMonto
      WHERE NoCuenta=@uNoCuenta
  
  IF @@ERROR = 0 
    COMMIT TRANSACTION PRUEBA5 
  ELSE 
    BEGIN 
    PRINT 'A transaction needs to be rolled back' 
    ROLLBACK TRANSACTION PRUEBA5 
  END 
GO

EXECUTE REGISTRAR_DEPOSITO_VENTANILLA '001', 500;

SELECT * FROM ClientesBanca WHERE NoCuenta = '001'