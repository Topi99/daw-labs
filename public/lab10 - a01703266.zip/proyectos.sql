﻿BULK INSERT a1703266.a1703266.[Proyectos]
   FROM 'e:\wwwroot\a1703266\proyectos.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

