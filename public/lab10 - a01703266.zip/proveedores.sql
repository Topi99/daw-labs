﻿BULK INSERT a1703266.a1703266.[Proveedores]
   FROM 'e:\wwwroot\a1703266\proveedores.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

