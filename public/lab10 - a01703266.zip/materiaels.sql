﻿BULK INSERT a1703266.a1703266.[Materiales]
   FROM 'e:\wwwroot\a1703266\materiales.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

